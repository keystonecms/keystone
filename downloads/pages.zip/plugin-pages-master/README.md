# Pages plugin #

## Features ##
- wysiwyg editor
- versioning
- content blocks (plugin)
- schedule release
- autosave
- draft/publish