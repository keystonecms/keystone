## [1.0.2](https://github.com/keystonecms/plugin-pages/compare/v1.0.1...v1.0.2) (2026-01-25)


### Bug Fixes

* corrected plugin.json ([c15ead0](https://github.com/keystonecms/plugin-pages/commit/c15ead028f15f439e224e99e690140d296ed1b28))
* corrected the plugin.json ([ffcaacc](https://github.com/keystonecms/plugin-pages/commit/ffcaaccf7be60020b88c6ff59dfe3e455a7f42c7))

## [1.0.1](https://github.com/keystonecms/plugin-pages/compare/v1.0.0...v1.0.1) (2026-01-25)


### Bug Fixes

* corrected JSON ([713304a](https://github.com/keystonecms/plugin-pages/commit/713304abe06a5f63735babc0f9fe29bba8c89de7))
* corrected plugin.json ([9dfa771](https://github.com/keystonecms/plugin-pages/commit/9dfa771f9ca62053499ebc675f8efd89ff39b701))

# 1.0.0 (2026-01-25)


### Bug Fixes

* added workflow and update composer.json ([a94133d](https://github.com/keystonecms/plugin-pages/commit/a94133d652c4ded22517f74a41ac5a5d8502c950))
* added workflow version and update composer ([2184ab9](https://github.com/keystonecms/plugin-pages/commit/2184ab90f0b02dc4a94e89841ca08a010bf7e9e5))
* changed the branch in version.yml ([bbeca46](https://github.com/keystonecms/plugin-pages/commit/bbeca466e99f9343a501f54f215a8b63d2d3745f))
* changed the readme file added some more information ([157ccf5](https://github.com/keystonecms/plugin-pages/commit/157ccf51be935b2d1f06e7deeffa2b84a214df9f))


### Features

* added json and releaserc.json ([0f8b0bf](https://github.com/keystonecms/plugin-pages/commit/0f8b0bfd55de6dc5a522ec767cffc8923b1714a0))
